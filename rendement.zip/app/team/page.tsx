import Image from "next/image";
import React from "react";

const TeamPage = () => {
  return (
    <main className='flex min-h-screen flex-col items-center justify-between scroll-snap-type-y smooth-scroll'>
      <header className='w-full scroll-snap-align-start'>
        <div className='flex flex-col items-center justify-center w-full relative h-[50dvh]'>
          <Image
            src={"/img/_decbeb1b-b988-4f7f-a31f-a8d23d6a36f1.jpg"}
            alt='Picture of the author'
            width={2000}
            height={2000}
            quality={100}
            className='w-full h-[50dvh] object-cover object-top fixed top-0 left-0 -z-10'
            placeholder="blur"
            blurDataURL=" " 
          />

          <div className='absolute bottom-0 left-0 right-0 w-full bg-black bg-opacity-70 z-10 p-20 backdrop-blur-md'>
            <h3 className='text-[48px] text-white w-full '>
              Rendement was founded in 2023 after years of collaboration of its
              members with consultancy and construction firms of high calibre in
              different countries.
              <br />
              With a total of over 50 years of experience, Our team is comprised
              of passionate professionals with vast experience in a range of
              fields.
            </h3>
          </div>
        </div>
      </header>
    </main>
  );
};

export default TeamPage;

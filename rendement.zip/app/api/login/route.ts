export async function GET(req: Request) {
  return Response.json({ message: "Hello, World!"});
}

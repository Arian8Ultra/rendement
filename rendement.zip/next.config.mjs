/** @type {import('next').NextConfig} */
const nextConfig = {};

if (process.env.NODE_ENV === "production") {
    nextConfig.assetPrefix = "https://rendement.chbk.run/";
  } else {
    nextConfig.assetPrefix = "http://localhost:3000/";
  }

export default nextConfig;
